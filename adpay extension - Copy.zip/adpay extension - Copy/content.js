console.log("Extension loaded")
